use std::collections::{HashMap, HashSet};

pub fn print_hash_map(map: &HashMap<K, V>) -> () {
    
}